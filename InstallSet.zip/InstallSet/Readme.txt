PROGRAM WILL NOT START?
1. Download and install Microsoft Visual C++
2. Launch the program
3. Restart your computer

PASS - osth